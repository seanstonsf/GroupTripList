//
//  LightBoxTransition.swift
//  RaptorFish
//
//  Created by Lin Wang on 11/4/15.
//  Copyright © 2015 Sean Smith. All rights reserved.
//

import UIKit

class LightBoxTransition: BaseTransition {

}
